// -------------------------------------------------------------------------------------------------
// Minimal pinmap for Arduino Giga R1 (M7 core)
// This is a minimal, experimental mapping. Please verify and replace pin numbers with correct values
// for your hardware before using for production.
#pragma once

#if defined(ARDUINO_GIGA_R1) || defined(ARDUINO_GIGAR1)

// Serial:  is used for the usb
//Serial1: RX0 Pin 0,  TX0 Pin 1
//Serial2: RX1 Pin 19,  TX1 Pin 18  Aux6 1 wire
//Serial3: RX2 Pin 17,  TX2 Pin 16  gps
//Serial4: RX3 Pin 15,  TX3 Pin 14  (TMC2209 UART)

// Serial ports
#ifndef SERIAL_A
#define SERIAL_A                    Serial1
#endif

#ifndef SERIAL_B
#define SERIAL_B                    Serial2
#endif

#ifndef SERIAL_C
#define SERIAL_C                    Serial3
#endif

#ifndef SERIAL_D
#define SERIAL_D                    Serial4
#endif

// Optional: specify RX/TX pins if needed by HAL or other code
// #define SERIAL_C_RX                15
// #define SERIAL_C_TX                14

#if !defined(SERIAL_GPS_BAUD) || SERIAL_GPS_BAUD == OFF
// Enable GPS on Serial2 (Hardware) by default for Giga R1. If you prefer to
// leave GPS disabled, override SERIAL_GPS_BAUD to OFF in your local config.
// Serial2 mapping on this board: RX = D19, TX = D18
  #undef SERIAL_GPS_BAUD
  #define SERIAL_GPS_BAUD         9600
  #ifndef SERIAL_GPS
    #define SERIAL_GPS            HardSerial
  #endif
  #ifndef SERIAL_GPS_RX
    #define SERIAL_GPS_RX         17
  #endif
  #ifndef SERIAL_GPS_TX
    #define SERIAL_GPS_TX         16
  #endif
#endif

// I2C
#ifndef I2C_SDA_PIN
#define I2C_SDA_PIN                 9
#endif
#ifndef I2C_SCL_PIN
#define I2C_SCL_PIN                 8
#endif

// Use the following settings for the 4x TMC UART drivers
#if defined(STEP_DIR_TMC_UART_PRESENT) || defined(SERVO_TMC2209_PRESENT)
  #define SERIAL_TMC_HARDWARE_UART
  #define DRIVER_TMC_STEPPER
  #define SERIAL_TMC            Serial4            // Use a single hardware serial port to up to four drivers
  #define SERIAL_TMC_BAUD       460800             // Baud rate
  #define SERIAL_TMC_ADDRESS_MAP(x) ((x==4)?2 : x) // Axis1(0) is 0, Axis2(1) is 1, Axis3(2) is 2, Axis4(3) is 3, Axis5(4) is 2
#endif

// Status led R-G-B pins D86-D87-D88
// The multi-purpose pins (Aux3..Aux8 can be analog pwm/dac if supported)
#define AUX0_PIN                86              // Status LED R
#define AUX1_PIN                15              // TMC SPI MISO or UART RX(Serial4)
#define AUX2_PIN                16              // PPS
#define AUX3_PIN                2               // Home SW
#define AUX4_PIN                3               // Home SW
#define AUX5_PIN                18              // 1-Wire TX1
#define AUX6_PIN                19              // RX1
#define AUX7_PIN                20              // Limit SW
#define AUX8_PIN                21              // Reticle LED, 1-Wire alternate

// Misc. pins
#ifndef ONE_WIRE_PIN
  #define ONE_WIRE_PIN          AUX5_PIN         // Default Pin for 1-Wire bus
#endif
#define ADDON_GPIO0_PIN         OFF              // ESP8266 GPIO0 (shared with AXIS2_DIR_PIN)
#define ADDON_RESET_PIN         OFF              // ESP8266 RST

// The PEC index sense is a logic level input, resets the PEC index on rising edge then waits for 60 seconds before allowing another reset
#define PEC_SENSE_PIN           76                // PEC Sense, analog or digital

// The status LED is a rgb led onboard
#define STATUS_LED_PIN          AUX0_PIN         // Default LED Cathode (-)
#define MOUNT_LED_PIN           AUX9_PIN         // Default LED Cathode (-)

// For a piezo buzzer
#ifndef STATUS_BUZZER_PIN 
  #define STATUS_BUZZER_PIN     77               // Tone
#endif

// The PPS pin is a 3.3V logic input, OnStep measures time between rising edges and adjusts the internal sidereal clock frequency
#ifndef PPS_SENSE_PIN
  #define PPS_SENSE_PIN         AUX2_PIN         // PPS time source, GPS for example (MaxSTM version 3.61 and later)
#endif

// The limit switch sense is a logic level input normally pull high (2k resistor,) shorted to ground it stops gotos/tracking
#ifndef LIMIT_SENSE_PIN
  #define LIMIT_SENSE_PIN       AUX7_PIN
#endif

// hint that the driver mode pins are dedicated (not shared SPI bus except possibly MISO)
#define DEDICATED_MODE_PINS

// Axis1 RA/Azm step/dir driver
#define AXIS1_ENABLE_PIN        22
#define AXIS1_M0_PIN            23               // SPI MOSI
#define AXIS1_M1_PIN            24               // SPI SCK
#define AXIS1_M2_PIN            25               // SPI CS (UART TX)
#define AXIS1_M3_PIN            AUX1_PIN         // SPI MISO (UART RX)
#define AXIS1_STEP_PIN          26
#define AXIS1_DIR_PIN           27
#ifndef AXIS1_SENSE_HOME_PIN
  #define AXIS1_SENSE_HOME_PIN  AUX3_PIN
#endif

// Axis2 Dec/Alt step/dir driver
#define AXIS2_ENABLE_PIN        28
#define AXIS2_M0_PIN            29               // SPI MOSI
#define AXIS2_M1_PIN            30               // SPI SCK
#define AXIS2_M2_PIN            31               // SPI CS (UART TX)
#define AXIS2_M3_PIN            AUX1_PIN         // SPI MISO (UART RX)
#define AXIS2_STEP_PIN          32
#define AXIS2_DIR_PIN           33
#ifndef AXIS2_SENSE_HOME_PIN
  #define AXIS2_SENSE_HOME_PIN  AUX4_PIN
#endif

// For rotator stepper driver
#define AXIS3_ENABLE_PIN        34
#define AXIS3_M0_PIN            35               // SPI MOSI
#define AXIS3_M1_PIN            36               // SPI SCK
#define AXIS3_M2_PIN            37               // SPI CS (UART TX)
#define AXIS3_M3_PIN            AUX1_PIN         // SPI MISO (UART RX)
#define AXIS3_STEP_PIN          38
#define SHARED_DIRECTION_PINS                    // Hint that the direction pins are shared
#define AXIS3_DIR_PIN           39

// For focuser1 stepper driver
#define AXIS4_ENABLE_PIN        40
#define AXIS4_M0_PIN            41               // SPI MOSI
#define AXIS4_M1_PIN            42               // SPI SCK
#define AXIS4_M2_PIN            43               // SPI CS (UART TX)
#define AXIS4_M3_PIN            AUX1_PIN         // SPI MISO (UART RX)
#define AXIS4_STEP_PIN          44
#define AXIS4_DIR_PIN           45

// For focuser2 stepper driver
#define AXIS5_ENABLE_PIN        46
#define AXIS5_M0_PIN            47               // SPI MOSI
#define AXIS5_M1_PIN            48               // SPI SCK
#define AXIS5_M2_PIN            49               // SPI CS (UART TX)
#define AXIS5_M3_PIN            AUX1_PIN         // SPI MISO (UART RX)
#define AXIS5_STEP_PIN          50
#define AXIS5_DIR_PIN           51

// ST4 interface
#define ST4_RA_W_PIN            80                // ST4 RA- West
#define ST4_DEC_S_PIN           81                // ST4 DE- South
#define ST4_DEC_N_PIN           82                // ST4 DE+ North
#define ST4_RA_E_PIN            83                // ST4 RA+ East

#else
// Unsupported processor for this pinmap; do not force a hard build error here so that
// higher-level build configuration or alternative pinmaps can handle the case.
// To re-enable the original behavior, uncomment the following line:
// #error "Wrong processor for this configuration!"
#endif


