// HAL for Arduino GIGA R1 (M7 core)
#pragma once

// Use STM32H7 family defaults as base but tweak for Arduino GIGA specifics
#define __ARM_STM32__

// Base rate for critical task timing (keep same as other H7 variants)
#define HAL_FRACTIONAL_SEC 526.3157895F

// Analog read and write defaults
#ifndef HAL_VCC
  #define HAL_VCC 3.3F
#endif
#ifndef ANALOG_READ_RANGE
  #define ANALOG_READ_RANGE 1023
#else
  #error "Configuration (Config.h): ANALOG_READ_RANGE can't be changed on this platform"
#endif
#ifndef ANALOG_WRITE_RANGE
  #define ANALOG_WRITE_RANGE 255
#endif

// Limits and flags
#define HAL_MAXRATE_LOWER_LIMIT 1.5
#define HAL_PULSE_WIDTH 0
#define HAL_FAST_PROCESSOR
#define HAL_VFAST_PROCESSOR

// Hardware timer helper: not available on mbed core by this name; avoid including it here.
// If a platform-specific timer wrapper is needed later, add it to this file or to the board's variant.

// Interrupts
#define cli() noInterrupts()
#define sei() interrupts()

// Default I2C (Wire)
#include <Wire.h>
#ifndef HAL_WIRE
  #define HAL_WIRE Wire
#endif
#ifndef HAL_WIRE_CLOCK
  #define HAL_WIRE_CLOCK 100000
#endif

// Non-volatile storage: prefer existing defaults in repo
#undef E2END
#if NV_DRIVER == NV_DEFAULT
  #undef NV_DRIVER
  #define NV_DRIVER NV_24256
#endif

// Internal MCU temperature (not implemented)
#define HAL_TEMP() ( NAN )

// General purpose initialize for HAL
#define HAL_INIT() { \
  analogWriteResolution((int)log2(ANALOG_WRITE_RANGE + 1)); \
}

// Avoid pulling in SoftwareSerial on mbed-based GIGA core - use hardware serials in pinmap
// (Do not include <SoftwareSerial.h> here)

// MCU reset
#define HAL_RESET() NVIC_SystemReset()

// a really short fixed delay (none needed)
#define HAL_DELAY_25NS()

// stand-in for delayNanoseconds()
#define delayNanoseconds(ns) delayMicroseconds(ceilf(ns/1000.0F))
