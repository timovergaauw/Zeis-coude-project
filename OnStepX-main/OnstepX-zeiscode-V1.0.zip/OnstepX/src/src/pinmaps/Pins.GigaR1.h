// -------------------------------------------------------------------------------------------------
// Minimal pinmap for Arduino Giga R1 (M7 core)
// This is a minimal, experimental mapping. Please verify and replace pin numbers with correct values
// for your hardware before using for production.
#pragma once

// Serial ports
#ifndef SERIAL_A
#define SERIAL_A                    Serial1
#endif

#ifndef SERIAL_B
#define SERIAL_B                    Serial2
#endif

// Optional: specify RX/TX pins if needed by HAL or other code
// #define SERIAL_B_RX                PA3
// #define SERIAL_B_TX                PA2

// I2C
#ifndef I2C_SDA_PIN
#define I2C_SDA_PIN                 OFF
#endif
#ifndef I2C_SCL_PIN
#define I2C_SCL_PIN                 OFF
#endif

// Default everything else to be handled by Pins.defaults.h

// Provide TMC driver serial defaults for Giga R1 (use hardware UART instead of SoftwareSerial)
#ifndef SERIAL_TMC
#define SERIAL_TMC                  Serial1
#endif
#ifndef SERIAL_TMC_BAUD
#define SERIAL_TMC_BAUD             115200
#endif
#ifndef SERIAL_TMC_HARDWARE_UART
#define SERIAL_TMC_HARDWARE_UART
#endif

